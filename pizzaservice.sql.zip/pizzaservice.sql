--
-- Datenbank: `pizzaservice`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `belag`
--

CREATE TABLE `belag` (
  `ID` int(11) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `BelagstypID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `belag`
--

INSERT INTO `belag` (`ID`, `Name`, `BelagstypID`) VALUES
(1, 'Schinken', 2),
(2, 'Salami', 2),
(3, 'Champignons', 2),
(4, 'Käse', 1),
(5, 'Zwiebeln', 1),
(6, 'Gyros', 2),
(7, 'Tunfisch', 2),
(8, 'Ananas', 2),
(9, 'Anchovies', 2),
(10, 'Scampi', 2),
(11, 'Hackfleisch', 2),
(12, 'Schafskäse', 1),
(13, 'Spinat', 1),
(14, 'Brokkoli', 1),
(15, 'Paprika', 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `belagstyp`
--

CREATE TABLE `belagstyp` (
  `ID` int(11) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `PreisS` double(6,2) NOT NULL,
  `PreisM` double(6,2) NOT NULL,
  `PreisL` double(6,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `belagstyp`
--

INSERT INTO `belagstyp` (`ID`, `Name`, `PreisS`, `PreisM`, `PreisL`) VALUES
(1, 'Einfach', 1.00, 1.50, 2.00),
(2, 'Speziell', 2.00, 2.50, 3.00);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `bestellung`
--

CREATE TABLE `bestellung` (
  `ID` int(11) NOT NULL,
  `KundenNr` int(11) NOT NULL,
  `Bonusgetraenk` int(11) DEFAULT NULL,
  `Status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `getraenk`
--

CREATE TABLE `getraenk` (
  `ID` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Preis` double(6,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `getraenk`
--

INSERT INTO `getraenk` (`ID`, `Name`, `Preis`) VALUES
(1, 'Cola', 3.50),
(2, 'Wasser', 2.00),
(3, 'Wein - Rot', 12.00);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `getraenkebestellung`
--

CREATE TABLE `getraenkebestellung` (
  `ID` int(11) NOT NULL,
  `GetraenkID` int(11) NOT NULL,
  `BestellungsID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `kunde`
--

CREATE TABLE `kunde` (
  `KundenNr` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Strasse` varchar(50) NOT NULL,
  `Ort` varchar(30) NOT NULL,
  `Plz` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `kunde`
--

INSERT INTO `kunde` (`KundenNr`, `Name`, `Strasse`, `Ort`, `Plz`) VALUES
(1, 'Hansen', 'Doof', 'hier', 12345),
(4, 'Stein', 'Loch2', 'andere wand', 12345),
(5, 'Kaninchen', 'Loch 42', 'Rasen', 54321),
(6, 'Wolf', 'Loch2', 'andere wand', 12345),
(7, 'Fabi', 'T', 'Hamburg', 12345),
(8, 'Oli', 'weg', 'ort', 12345);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `pizza`
--

CREATE TABLE `pizza` (
  `ID` int(11) NOT NULL,
  `Pizzagroesse` varchar(10) NOT NULL,
  `Bestellungsid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `pizzabelag`
--

CREATE TABLE `pizzabelag` (
  `ID` int(11) NOT NULL,
  `PizzaID` int(11) NOT NULL,
  `BelagID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `pizzagroesse`
--

CREATE TABLE `pizzagroesse` (
  `Groesse` varchar(10) NOT NULL,
  `Preis` double(6,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `pizzagroesse`
--

INSERT INTO `pizzagroesse` (`Groesse`, `Preis`) VALUES
('Large', 6.00),
('Medium', 4.50),
('Small', 3.00);

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `belag`
--
ALTER TABLE `belag`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `Name` (`Name`),
  ADD KEY `BelagstypID` (`BelagstypID`);

--
-- Indizes für die Tabelle `belagstyp`
--
ALTER TABLE `belagstyp`
  ADD PRIMARY KEY (`ID`);

--
-- Indizes für die Tabelle `bestellung`
--
ALTER TABLE `bestellung`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `KundenNr` (`KundenNr`),
  ADD KEY `Bonusgetraenk` (`Bonusgetraenk`);

--
-- Indizes für die Tabelle `getraenk`
--
ALTER TABLE `getraenk`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `Name` (`Name`);

--
-- Indizes für die Tabelle `getraenkebestellung`
--
ALTER TABLE `getraenkebestellung`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `GetraenkID` (`GetraenkID`,`BestellungsID`),
  ADD KEY `BestellungsID` (`BestellungsID`);

--
-- Indizes für die Tabelle `kunde`
--
ALTER TABLE `kunde`
  ADD PRIMARY KEY (`KundenNr`);

--
-- Indizes für die Tabelle `pizza`
--
ALTER TABLE `pizza`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Bestellungsid` (`Bestellungsid`),
  ADD KEY `Pizzatyp` (`Pizzagroesse`);

--
-- Indizes für die Tabelle `pizzabelag`
--
ALTER TABLE `pizzabelag`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `BelagID` (`BelagID`),
  ADD KEY `PizzaID` (`PizzaID`);

--
-- Indizes für die Tabelle `pizzagroesse`
--
ALTER TABLE `pizzagroesse`
  ADD PRIMARY KEY (`Groesse`),
  ADD UNIQUE KEY `Groesse` (`Groesse`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `belag`
--
ALTER TABLE `belag`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT für Tabelle `belagstyp`
--
ALTER TABLE `belagstyp`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT für Tabelle `bestellung`
--
ALTER TABLE `bestellung`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;
--
-- AUTO_INCREMENT für Tabelle `getraenk`
--
ALTER TABLE `getraenk`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT für Tabelle `getraenkebestellung`
--
ALTER TABLE `getraenkebestellung`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT für Tabelle `kunde`
--
ALTER TABLE `kunde`
  MODIFY `KundenNr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT für Tabelle `pizza`
--
ALTER TABLE `pizza`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;
--
-- AUTO_INCREMENT für Tabelle `pizzabelag`
--
ALTER TABLE `pizzabelag`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;
--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `belag`
--
ALTER TABLE `belag`
  ADD CONSTRAINT `belag_ibfk_1` FOREIGN KEY (`BelagstypID`) REFERENCES `belagstyp` (`ID`);

--
-- Constraints der Tabelle `bestellung`
--
ALTER TABLE `bestellung`
  ADD CONSTRAINT `bestellung_ibfk_1` FOREIGN KEY (`KundenNr`) REFERENCES `kunde` (`KundenNr`),
  ADD CONSTRAINT `bestellung_ibfk_2` FOREIGN KEY (`Bonusgetraenk`) REFERENCES `getraenk` (`ID`);

--
-- Constraints der Tabelle `getraenkebestellung`
--
ALTER TABLE `getraenkebestellung`
  ADD CONSTRAINT `getraenkebestellung_ibfk_1` FOREIGN KEY (`GetraenkID`) REFERENCES `getraenk` (`ID`),
  ADD CONSTRAINT `getraenkebestellung_ibfk_2` FOREIGN KEY (`BestellungsID`) REFERENCES `bestellung` (`ID`);

--
-- Constraints der Tabelle `pizza`
--
ALTER TABLE `pizza`
  ADD CONSTRAINT `pizza_ibfk_1` FOREIGN KEY (`Pizzagroesse`) REFERENCES `pizzagroesse` (`Groesse`),
  ADD CONSTRAINT `pizza_ibfk_2` FOREIGN KEY (`Bestellungsid`) REFERENCES `bestellung` (`ID`);

--
-- Constraints der Tabelle `pizzabelag`
--
ALTER TABLE `pizzabelag`
  ADD CONSTRAINT `pizzabelag_ibfk_1` FOREIGN KEY (`BelagID`) REFERENCES `belag` (`ID`),
  ADD CONSTRAINT `pizzabelag_ibfk_2` FOREIGN KEY (`PizzaID`) REFERENCES `pizza` (`ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
